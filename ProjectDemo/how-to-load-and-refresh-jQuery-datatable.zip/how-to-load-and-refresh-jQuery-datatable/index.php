<?php 
include('header.php');
?>
<title>phpzag.com : Demo Load and Refresh jQuery DataTable without Loosing Current Page with PHP</title>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.css">  
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="script/script.js"></script>
<?php include('container.php');?>
<div class="container">
	<h2>Load and Refresh jQuery DataTable without Loosing Current Page with PHP</h2>	
	<div class="row">
		
		<table id="example" class="display" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>Empid</th>
                <th>Name</th>
                <th>Salary</th>
               
            </tr>
        </thead>       
    </table>	
	</div>	
	<div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="http://www.phpzag.com/load-and-refresh-jquery-datatable-with-php" title="">Back to Tutorial</a>			
	</div>		
</div>
<?php include('footer.php');?>

