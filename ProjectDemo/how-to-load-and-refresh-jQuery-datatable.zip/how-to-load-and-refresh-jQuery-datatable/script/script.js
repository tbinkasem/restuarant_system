$( document ).ready(function() {	
	var table = $('#example').DataTable( {
		"ajax": "data.php",
		"bPaginate":true,
		"bProcessing": true,
		"pageLength": 5,
		"columns": [
			{ mData: 'Empid' } ,
			{ mData: 'Name' },
			{ mData: 'Salary' }
		]
	});	
	setInterval( function () {
		table.ajax.reload(null, false);
	}, 5000 );	
});