<?php 
include_once("db_connect.php");
?>
<title>phpzag.com : Demo Inline Editing using PHP MySQL and jQuery Ajax</title>
<script type="text/javascript" src="script/functions.js"></script>
<div class="container">
	<h2>Example: Inline Editing using PHP MySQL and jQuery ajax</h2>
	<?php
	$sql = "SELECT id, employee_name, employee_salary, employee_age FROM employee LIMIT 5";
	$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));
	?>
	<table class="table table-condensed table-hover table-striped bootgrid-table">
		<thead>
		  <tr>			
			<th>Employee Name</th>
			<th>Salary</th>
			<th>Age</th>				
		  </tr>
		</thead>
		<tbody>
		 <?php
		 while( $rows = mysqli_fetch_assoc($resultset) ) { 
		 ?>
			  <tr>				  
				  <td contenteditable="true" data-old_value="<?php echo $rows["employee_name"]; ?>" onBlur="saveInlineEdit(this,'employee_name','<?php echo $rows["id"]; ?>')" onClick="highlightEdit(this);"><?php echo $rows["employee_name"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $rows["employee_salary"]; ?>"  onBlur="saveInlineEdit(this,'employee_salary','<?php echo $rows["id"]; ?>')" onClick="highlightEdit(this);"><?php echo $rows["employee_salary"]; ?></td>
				  <td contenteditable="true" data-old_value="<?php echo $rows["employee_age"]; ?>"  onBlur="saveInlineEdit(this,'employee_age','<?php echo $rows["id"]; ?>')" onClick="highlightEdit(this);"><?php echo $rows["employee_age"]; ?></td>
			  </tr>
		<?php
		}
		?>
		</tbody>
	</table>		  
		  
	<div style="margin:50px 0px 0px 0px;">
		<a class="btn btn-default read-more" style="background:#3399ff;color:white" href="http://www.phpzag.com/inline-editing-using-php-mysql-and-jquery-ajax" title="Inline Editing using PHP MySQL and jQuery ajax">Back to Tutorial</a>			
	</div>		
</div>
